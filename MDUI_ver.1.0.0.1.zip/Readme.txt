Dongjae Shin, Department of Chemical Engineering, University of Seoul
(MDUI.exe, md_my_simulation_autocorr.exe)
Sangwon Lee, Department of Chemical Engineering, University of Seoul
(Molecule Viewer)

Please send me an e-mail to ask anything about MDUI ver. 1.0.0.1

e-mail: djshin0530@gmail.com
